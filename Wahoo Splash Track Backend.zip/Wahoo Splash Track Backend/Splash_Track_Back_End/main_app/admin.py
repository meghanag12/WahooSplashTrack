from django.contrib import admin
from .models import Swimmer, Start
# Create your models here.

admin.site.register(Swimmer)
admin.site.register(Start)